<!-- _coverpage.md -->

![logo](_media/logo.svg)

# Solve3<small>docs</small>

> Bot Protection for Smart Contracts


[GitHub](https://github.com/solve3-org/)
[Get Started](contract)